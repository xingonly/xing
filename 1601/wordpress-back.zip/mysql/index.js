var mysql = require("mysql")
function createConnection(){
    var connection = mysql.createConnection({
        host:"localhost",
        port:3306,
        user:"root",
        password:"root",
        database:"mywordpress"
    })
    return connection
}

// connection.connect((err)=>{
//     if(err) throw err;
//     console.log("ok")
// });

var queryFn = {
    select(sql,query=[]){
        let connection = createConnection()
        return new Promise((reslove,reject)=>{
            connection.query(sql,query,function(err,rows){
                if(err){
                    reject({mag:"err",err,status:"0"})
                }else{
                    reslove({mag:"success",rows,status:"1"})
                }
                connection.end()
            })
        })
    },
    insertInto(sql,query=[]){
        let connection = createConnection()
        return new Promise((reslove,reject)=>{
            connection.query(sql,query,function(err){
                if(err){
                    reject({mag:"err",err,status:"0"})
                }else{
                    reslove({mag:"success",status:"1"})
                }
                connection.end()
            })
        })
    }
}
module.exports = queryFn