var express = require('express');
var router = express.Router();
var path = require("path")
let {select,insertInto} = require("../../mysql/index")
router.post('/save',(req,res,next)=>{
    res.set("Access-Control-Allow-Origin","*");
    let {name,pass} = req.body;
    var nn = /[^\u4E00-\u9FA5 A-Z]/g;
    var pp = /\w+/;
    if(name == "" && pass == ""){
        res.json({mag:"用户名为空"})
    }else if(!nn.test(name) && !pp.test(pass)){
        res.json({mag:"用户名或密码输入有误"})
    }else{
        select(`select user_name,user_password from users where user_name=?`,[name]).then((info)=>{
            if(info.rows.length === 0){
                res.json({mag:"该用户不存在",status:"no"})
            }else if(info.rows[0].user_password === pass){
                res.json({mag:"登陆成功",status:"ok"})
            }else{
                res.json({mag:"密码错误",status:"ok"})
            }
            res.json(info);
        },(info)=>{
            res.json(info);
        })
    }
    
    
})
module.exports = router;
