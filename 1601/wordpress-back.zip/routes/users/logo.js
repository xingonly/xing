var express = require('express');
var router = express.Router();
const path = require("path");
let {select,insertInto} = require(path.join(__dirname,"../../mysql"))
router.get("/log",(req,res,next)=>{
    res.send({mag:"ok"})
})
module.exports = router