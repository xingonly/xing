import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import HelloView from '@/components/HelloView'
import Login from "@/components/Login"
import Child from "@/components/page/child"
import Blog from "@/components/page/Blog"
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      components:{
        default:HelloWorld,
        view:HelloView
      },
      children:[
        {
          path:"child",
          name:"Child",
          component:Child
        }
      ]
    },{
      path:"/login",
      name:"Login",
      component:Login,
    },{
      path:"/Blog",
      name:"Blog",
      component:Blog
    }
  ]
})
