<template>
    <div>
       <button @click="addNum_A">num++</button>
    </div>
   
</template>
<script>
    import {mapState,mapActions} from "vuex"
    export default {
        methods:mapActions(['addNum_A']),
    }
</script>
<style>

</style>
