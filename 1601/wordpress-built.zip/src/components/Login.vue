<template>
  <div id="login">
    <div id="login_box">
      <h1>
        <a class="el-icon-success"></a>
      </h1>
      <div id="login_error" class="bg" v-show="error"><strong>错误</strong>{{msg}}</div>
      <div id="login_fff">
        <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" class="demo-ruleForm">
          <el-form-item label="用户名或电子邮件地址" prop="name">
            <el-input v-model.number="ruleForm2.name"></el-input>
          </el-form-item>
          <el-form-item label="密码" prop="pass">
            <el-input type="password" v-model="ruleForm2.pass" auto-complete="off"></el-input>
          </el-form-item>
          <form id="log">
            <p>
              <span class="rem_inp"><input type="checkbox" :checked="state" @change="changeFn"></span>
              <span class="rem_span">记住我的登录信息</span>
            </p>
            <el-button type="primary" @click="submitForm('ruleForm2')">登录</el-button>
          </form>
        </el-form>
      </div>
    </div>
    
    
  </div>
</template>

<script>
import axios from "axios"
import {mapState,mapActions} from "vuex"
  export default {
    data() {
      var checkAge = (value, callback) => {
        if (!value) {
          return callback(new Error('用户名不能为空'));
        }
      };
      var validatePass = (value, callback) => {
        if (value === '') {
          return callback(new Error('请输入密码'));
        }
      };
      return {
        ruleForm2: {
          pass: '',
          name: ''
        },
        rules2: {
          pass: [
            { validator: validatePass}
          ],
          name: [
            { validator: checkAge}
          ]
        },
        msg:"",
        state:false,
        error:false
      };
    },
    mounted(){
      
    },
    computed:{
      ...mapState(['num','host'])
    },
    methods: {
      toString(obj){
        let str = Object.keys(obj).map((val,ind)=>{
          return val + "=" + obj[val]
        }).join("&")
        return str;
      },
      submitForm(formName) {
        if(this.ruleForm2.name == "" && this.ruleForm2.pass == ""){
          this.error = false
        }else{
          this.error = true
          let str = this.toString({
            name:this.ruleForm2.name,
            pass:this.ruleForm2.pass,
          })
          axios.post(this.host+"/save",str).then((data)=>{
            console.log(data);
            if(data.data.mag == "登陆成功"){
              console.log("dsv")
              this.$router.push('/blog')
            }else{
              this.msg = data.data.mag
            }
            
          });
        }
      },
      changeFn(){
        this.state = !this.state;
        var local = window.localStorage;
        var dataObj = {}
        if(this.state == true){
          dataObj.name = this.ruleForm2.name;
          dataObj.pwd = this.ruleForm2.pass;
          local.setItem("user",JSON.stringify(dataObj))
        }
      }
    }
  }
</script>

<style>
  #login{
    width: 100%;
    height: 100%;
    background: #eee;
  }
  #login_box{
    position: absolute;
    top:50%;
    left:50%;
    width: 250px;
    height: 400px;
    margin-left: -125px;
    margin-top: -220px;
  }
  #login_box h1{
    width: 290px;
    text-align: center;
  }
  #login_box h1 a{
    text-align: center;
    font-size: 80px;
    color: #008ec2;
    
  }
  #login_error{
    width: 286px;
    background: #fff;
    padding:10px 0;
    margin-top: 20px;
    border-left: 4px solid #00a0d2;
    font-size: 12px;
  }
  
  #login_error strong{
    font-weight: bold;
    margin:0 10px;
    color:#444;
    font-size: 13px;
  }
  .bg{
    border-left-color: #dc3232!important;
  }
  #login_fff{
    background: #fff;
    width: 250px;
    height: 230px;
    padding:20px;
    border:1px solid #ccc;
    margin-top: 20px;
  }
  .el-form-item{
    margin-bottom:0px;
  }
  #log{
    display: flex;
    margin-top: 20px;;
  }
  #log p{
    flex:6;
    align-items: center;
    display: flex;
  }
  #log p .rem_inp{
    width: 25px;
    height: 25px;
    display: block;
    text-align: center;
    line-height: 25px;
    margin-right: 5px;
  }
  #log p .rem_inp input{
    width: 25px;
    height: 25px;
    
  }
  #log p .rem_span{
    font-size: 12px;
    color:#444;
  }
  #log button{
    flex:2;
  }
</style>
