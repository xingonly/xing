<template>
  <div class="hello">
    {{msg}}
    <!-- <button @click="getClick">get</button>
    <button @click="postClick">post</button>
    <button @click="aa">aa</button> -->
    <button @click="bing">bing</button>
    <button @click="ji">ji</button>
    <h2>{{num}}</h2>
    <h1>{{$store.state.num}}</h1>
    <router-view></router-view>
  </div>
</template>
<script>
import {mapState,mapActions} from "vuex"
import axios from "axios"
export default {
  name: 'HelloWorld',
  data(){
    return {
      msg:"def"
    }
  },
  computed:{
    ...mapState(['num','host'])
  },
  mounted(){
    //console.log(mapState(['num','host']))
  },
  methods:{
    // getClick(){
    //   axios.get(this.host+"/test").then((data)=>{
    //     this.msg = data.data.title
    //   })
     
    // },
    // postClick(){
    //   let str = this.toString({
    //     id:123,
    //     username:"zxz",
    //     pwd:1234
    //   })
    //   // axios.post(this.host+"/list",str).then((data)=>{
    //   //   console.log(data.data)
    //   //   this.msg = data.data.title
    //   // })
    // },
    // toString(obj){
    //   let str = Object.keys(obj).map((val,ind)=>{
    //     return val + "=" + obj[val]
    //   }).join("&")
    //   return str;
    // },
    // aa(){
    //   axios.post(this.host+"/asend").then((data)=>{
    //     console.log(data.data)
    //   })
    // },
    bing(){
      // let num = 0;
      // let arr = []
      // function bf(data){
      //   num++;
      //   if(num==2){
      //     console.log(data+arr[0])
      //   }else{
      //     arr.push(data)
      //   }
      // }
      // axios.get(this.host+"/one").then((data)=>{
      //   bf(data.data.msg)
      // })
      // axios.get(this.host+"/two").then((data)=>{
      //   bf(data.data.msg)
      // })
      function backData(url){
        return new Promise((reslove,reject)=>{
          axios.post(url).then((data)=>{
            reslove(data.data)
          })
        })
      }
      //继发
      async function getData(host){
        let one = await backData(host+"/test")
        let two = await backData(host+"/list")
        console.log(one.title+two.title)
      }
      // getData(this.host)

      //并发
      async function getDatas(host){
        let o = backData(host+"/test");
        let t = backData(host+"/list");
        let one = await o;
        let two = await t
        console.log(one.title+two.title)
      }
      getDatas(this.host)


    },
    ji(){
      axios.get(this.host+"/one").then((data)=>{
        console.log(data.data)
        return axios.get(this.host+'/two')
      }).then((data)=>{
        console.log(data.data)
      })
      
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
