<template>
  <div id="child">
    <div class="box" :style='{position:"absolute",left:left+"px",top:top+"px"}'>
          <div class="title" @mousedown="dragClick" @click="show">标题</div>
          <div class="conent" v-show="isshow">svd</div>
    </div>
  </div>
</template>

<script>
export default {
  data(){
    return{
      left:0,
      top:200,
      isshow:false
    }
  },
  methods:{
    dragClick(e){
      this.startTime = new Date().getTime()
      this.leftX = e.clientX - this.left 
      this.topY = e.clientY - this.top
      document.addEventListener("mousemove",this.move,false)
      document.addEventListener("mouseup",this.mouseUp,false)
    },
    move(e){
      this.left = e.clientX - this.leftX;
      this.top = e.clientY - this.topY;
    },
    mouseUp(){
      document.removeEventListener("mousemove",this.move,false)
      document.removeEventListener("mouseup",this.mouseUp,false)
    },
    show(){
      this.endTime = new Date().getTime()
      var time = this.endTime - this.startTime 
      console.log(time)
      if(time<=120){
        this.isshow = !this.isshow
      }
      
    }
  }

}
</script>

<style>
  .title{
    width: 100px;
    height: 30px;
    background: skyblue;
  }
  .conent{
    width: 100px;
    height: 70px;
    background: pink;
  }
</style>
