<template>
  <div id='blog'>
     
  </div>
</template>
<script>
    export default {
        data(){
            return {

            }
        }
    }
</script>
<style>

</style>
