import Vue from "vue"
import Vuex from "vuex"
Vue.use(Vuex)
export default new Vuex.Store({
    state:{
        num:0,
        host:"http://localhost:3000/login"
    },
    actions:{
        addNum_A({commit}){
            commit("addNum")
        }
    },
    mutations:{
        addNum(state){
            state.num++;
        }
    },
    getter:{
        dis(state,getters){
            console.log(getters)
        }
    }
})